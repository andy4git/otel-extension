
# Check if the first parameter exists
if [ -z "$1" ]; then
  echo "name space is not set"
  echo "Usage: configmap.sh gtw"
  exit 1
else
  echo "update or create config map oag-gtw-custom-cfg in name space '$1'"
fi


kubectl delete configmap oag-gtw-custom-cfg -n $1
kubectl create configmap oag-gtw-custom-cfg -n $1 --from-file=oag-gtw-custom.cfg=./oag-gtw-custom.cfg

 